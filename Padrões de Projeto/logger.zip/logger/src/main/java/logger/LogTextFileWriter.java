package logger;

public class LogTextFileWriter implements ILogMessageWriter{

	@Override
	public void write(String logMessage) throws LogException {
		// TODO Auto-generated method stub
		
	}

}
