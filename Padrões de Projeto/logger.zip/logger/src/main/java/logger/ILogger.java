package logger;

public interface ILogger
{
   void log(String logMessage) throws LogException;
}
