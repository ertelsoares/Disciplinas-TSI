package logger;

public class FileLogger extends AbstractLogger
{

	public FileLogger() {
		super(new SimpleLogMessageValidator(),
				new LogMessageTextFileWriter());
	}

	
    



	

	

	
	
	
}
