package logger;

public interface ILogMessageValidator   {
   
	void valitade(String logMessage) throws LogException;
}
