package logger;

public class LogNoSQLDatabaseWriter implements ILogMessageWriter{

	@Override
	public void write(String logMessage) throws LogException {
		// TODO Auto-generated method stub
		
	}

}
