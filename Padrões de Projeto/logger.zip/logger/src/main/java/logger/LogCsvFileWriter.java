package logger;

public class LogCsvFileWriter implements ILogMessageWriter{

	@Override
	public void write(String logMessage) throws LogException {
		// TODO Auto-generated method stub
		
	}

}
